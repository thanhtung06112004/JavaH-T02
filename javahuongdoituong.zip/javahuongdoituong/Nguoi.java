
public class Nguoi {

}
